package com.example.calculonotas12301973

import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Inicialização segura dos componentes com tipos explícitos
        val btnCalcular: MaterialButton = findViewById(R.id.btnCalcular)
        val etNota1: TextInputEditText = findViewById(R.id.etNota1)
        val etNota2: TextInputEditText = findViewById(R.id.etNota2)
        val tvResultado: TextView = findViewById(R.id.tvResultado)

        btnCalcular.setOnClickListener {
            try {
                // Validação dos campos
                when {
                    etNota1.text.isNullOrEmpty() -> {
                        showToast("Digite a primeira nota")
                        return@setOnClickListener
                    }
                    etNota2.text.isNullOrEmpty() -> {
                        showToast("Digite a segunda nota")
                        return@setOnClickListener
                    }
                }

                // Conversão e validação das notas
                val nota1 = etNota1.text.toString().toDouble().also {
                    if (it !in 0.0..10.0) {
                        showToast("Nota 1 deve estar entre 0 e 10")
                        return@setOnClickListener
                    }
                }

                val nota2 = etNota2.text.toString().toDouble().also {
                    if (it !in 0.0..10.0) {
                        showToast("Nota 2 deve estar entre 0 e 10")
                        return@setOnClickListener
                    }
                }

                // Cálculo da média (arredondada para 1 casa decimal)
                val media = ((nota1 + nota2) / 2 * 10).roundToInt() / 10.0

                // Determinação da situação do aluno
                val situacao = when {
                    media == 10.0 -> "Aprovado com Distinção"
                    media >= 7 -> "Aprovado"
                    else -> "Reprovado"
                }

                // Exibição do resultado
                tvResultado.text = "Média: $media\nSituação: $situacao"
                tvResultado.visibility = View.VISIBLE

            } catch (e: NumberFormatException) {
                showToast("Digite valores numéricos válidos")
            }
        }
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}