package com.example.minecraft12301973

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import kotlin.math.pow

class MainActivity : AppCompatActivity() {

    private lateinit var spinnerMaterial: Spinner
    private lateinit var editTextConstrutores: EditText
    private lateinit var btnCalcular: Button
    private lateinit var textViewResultado: TextView

    private val temposBase = mapOf(
        "Madeira" to 100.0,
        "Ouro" to 50.0,
        "Diamante" to 25.0
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        spinnerMaterial = findViewById(R.id.spinnerMaterial)
        editTextConstrutores = findViewById(R.id.editTextConstrutores)
        btnCalcular = findViewById(R.id.btnCalcular)
        textViewResultado = findViewById(R.id.textViewResultado)

        val materiais = listOf("Madeira", "Ouro", "Diamante")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, materiais)
        spinnerMaterial.adapter = adapter

        btnCalcular.setOnClickListener {
            calcularTempo()
        }
    }

    private fun calcularTempo() {
        val materialSelecionado = spinnerMaterial.selectedItem.toString()
        val construtores = editTextConstrutores.text.toString().toIntOrNull() ?: 1
        val tempoBase = temposBase[materialSelecionado] ?: 100.0

        // Redução do tempo conforme número de construtores (tempoBase / 2^(construtores - 1))
        val tempoCalculado = tempoBase / (2.0.pow(construtores - 1))

        textViewResultado.text = "Tempo estimado de construção: %.2f horas.".format(tempoCalculado)
    }
}
